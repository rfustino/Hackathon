A simple, fast example of layer 2 named-token-like-functionality, based on Nickolai's auction implementation.

TODO: More and better README content.

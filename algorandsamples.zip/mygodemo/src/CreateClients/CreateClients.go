package main

import (
	"fmt"

	"github.com/algorand/go-algorand-sdk/client/algod"
	"github.com/algorand/go-algorand-sdk/client/kmd"
)

const algodAddress = "http://r1.algorand.network:8161"
const kmdAddress = "http://localhost:7833"
const algodToken = "2b4e2a58208a0f5b624b77cb6b92749a1552f3d34bbc1e007609cde59852729f"
const kmdToken = "5e3ee1752c35b05d72f7214fba9afed670e0ad94cea2f54771b5c9979ce404b3"

func main() {
	// Create an algod client
	algodClient, err := algod.MakeClient(algodAddress, algodToken)
	if err != nil {
		return
	}

	// Create a kmd client
	kmdClient, err := kmd.MakeClient(kmdAddress, kmdToken)
	if err != nil {
		return
	}

	fmt.Printf("algod: %T, kmd: %T\n", algodClient, kmdClient)
}

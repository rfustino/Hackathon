package main

import (
	"encoding/gob"
	"flag"
	"fmt"
	"os"

	"github.com/algorand/go-algorand-sdk/client/algod"
	_ "github.com/algorand/go-algorand-sdk/crypto"
	_ "github.com/algorand/go-algorand-sdk/transaction"
)

// this needs to be setup first https://medium.com/algorand/l2-applications-on-algorand-make-your-own-coin-6d62c5d5578d
//
// This util is a tool that crawls the blockchain
// and outputs a csv file of the current examplecoin state.
//var mastercoinKey = flag.String("coinkey", "", "The pubkey of the coin's manager.")
var verboseFlag = flag.Bool("verbose", false, "Print extra debug info during operation.")

const algodAddress = "http://localhost:8081"
const kmdAddress = "http://localhost:7833"
const algodToken = "ec068ed68dc176e61a07b897c53835c6fb956271ce70aad3b204f0db6fa34f6d"

//const kmdToken = "your kmdToken"

// where to get this from? creat an account (not in a wallet - aznd xfer funds to it from dispenser)
// inititalize coin
// transfer coins

// var mastercoinKey = "PEQLYX6XAM775SZ3B6JWT5WT64VQLUIDXB54IXTROTW3S2YNRC53K7YUYQ"

func main() {
	// must transfer 100000 first to this account from TestNet Dispenser to satify minimum requirement of reveiver balance
	//  https://bank.testnet.algorand.network/
	receiverKey := "MZERLMKA74OWTGAORNP7BFYS4Q63NRE2PETQ3NQY7VKGXJEWWRDSW3UGTU"

	// backupPhrase := "hockey razor script dial worry vital member basic tail mad armor bean leaf staff bargain brass evil satisfy frequent dragon deal never blue abstract east"

	//total token supply
	// supply := uint64(100)

	// create token in note field
	// produces an Initialize struct, wrapped in the NoteField struct, and encoded in base64 bytes
	// initNoteBytes64 := examplecoin.BuildInitializeNote(supply)

	//	initNoteString, _ := initNoteBytes64.MarshalText()
	// amountToSend := supply / 2

	// get privatekey from mnumonic

	// sk, err := mnemonic.ToPrivateKey(backupPhrase)
	// fmt.Printf("backup phrase = %s\n", sk)

	// transferNoteBytes64 := examplecoin.BuildTransferNote(amountToSend, mastercoinKey, receiverKey)

	// todo
	// transferNoteString, _ := transferNoteBytes64.MarshalText()
	// fmt.Fprintf(os.Stderr, "transferNoteBytes64 looks like %v    \n", transferNoteBytes64)
	// fmt.Fprintf(os.Stderr, "initNoteBytes64 looks like %v    \n", initNoteBytes64)
	// fmt.Fprintf(os.Stderr, "transferNote looks like %v   \n", string(transferNoteString))

	// flag.Parse()
	// Make transaction.  see the godoc for general transacting information.
	//	fromAddr := mastercoinKey
	//	toAddr := receiverKey

	// Create an algod client
	algodClient, err := algod.MakeClient(algodAddress, algodToken)
	if err != nil {
		fmt.Printf("failed to make algod client: %s\n", err)
		return
	}

	// // Get the suggested transaction parameters
	// txParams, err := algodClient.SuggestedParams()
	// if err != nil {
	// 	fmt.Printf("error getting suggested tx params: %s\n", err)
	// 	return
	// }

	// // Make transaction
	// genID := txParams.GenesisID

	// initExamplecoinTxn, err := transaction.MakePaymentTxn(fromAddr, toAddr, txParams.Fee, 0, (txParams.LastRound), (txParams.LastRound + 1000), initNoteBytes64, "", genID)
	// if err != nil {
	// 	fmt.Printf("Error creating transaction: %s\n", err)
	// 	return
	// }

	// fmt.Fprintf(os.Stderr, "initExamplecoinTxn looks like %v    \n", initExamplecoinTxn)

	// fmt.Printf("Made unsigned transaction: %+v\n", initExamplecoinTxn)
	// fmt.Println("Signing transaction with go-algo-sdk library function (not kmd)")
	// //Sign the Transaction
	// txid, stx, err := crypto.SignTransaction(sk, initExamplecoinTxn)
	// if err != nil {
	// 	fmt.Printf("Failed to sign transaction: %s\n", err)
	// 	return
	// }
	// //Save the signed object to disk
	// fmt.Printf("Made signed transaction with TxID %s: %x\n", txid, stx)

	//read the file
	var signedTransaction []byte
	file, err := os.Open("../stx.gob")
	if err == nil {
		decoder := gob.NewDecoder(file)
		err = decoder.Decode(&signedTransaction)
	} else {
		fmt.Printf("failed to open signed transaction: %s\n", err)
		return
	}
	file.Close()

	fmt.Printf("Opened signed transaction to file\n")
	// Broadcast the transaction to the network

	sendResponse, err := algodClient.SendRawTransaction(signedTransaction)
	if err != nil {
		fmt.Printf("failed to send transaction: %s\n", err)
		return
	}
	fmt.Printf("Transaction ID: %s\n", sendResponse.TxID)
	// need to add particpation key and then bring online to see it?

	tx, err := algodClient.TransactionInformation(receiverKey, sendResponse.TxID)
	if err != nil {
		fmt.Printf("failed to get transaction information: %s\n", err)
		return
	}
	fmt.Printf("Transaction Info Note: %s\n", tx.Note)

	// now decode it for display

	return

}

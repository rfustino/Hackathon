package main

import (
	"encoding/gob"
	"fmt"
	"os"

	"github.com/algorand/go-algorand-sdk/client/algod"
)

// CHANGE ME
const algodAddress = "http://127.0.0.1:8080"
const algodToken = "your algodToken"

func main() {

	var signedTransaction []byte
	file, err := os.Open("./stx.gob")
	if err == nil {
		decoder := gob.NewDecoder(file)
		err = decoder.Decode(&signedTransaction)
	} else {
		fmt.Printf("failed to open signed transaction: %s\n", err)
		return
	}
	file.Close()
	// Create an algod client
	algodClient, err := algod.MakeClient(algodAddress, algodToken)
	if err != nil {
		fmt.Printf("failed to make algod client: %s\n", err)
		return
	}

	// Broadcast the transaction to the network
	sendResponse, err := algodClient.SendRawTransaction(signedTransaction)
	if err != nil {
		fmt.Printf("failed to send transaction: %s\n", err)
		return
	}

	fmt.Printf("Transaction ID: %s\n", sendResponse.TxID)
}

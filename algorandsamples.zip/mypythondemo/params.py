from os.path import expanduser
home = expanduser("~")

# change these after starting the node and kmd
# algod info is in the algod.net and algod.token files in the data directory
# kmd info is in the kmd.net and kmd.token files in the kmd directory in data
# change these after starting the node and kmd

kmd_token = "5e3ee1752c35b05d72f7214fba9afed670e0ad94cea2f54771b5c9979ce404b3"
kmd_address = "http://localhost:7833"

algod_token = "2b4e2a58208a0f5b624b77cb6b92749a1552f3d34bbc1e007609cde59852729f"
algod_address = "http://r1.algorand.network:8161"




# path to the data directory
data_dir_path = home + "/node/datanode2"
kmd_folder_name = "kmd-v0.5"  # name of the kmd folder in the data directory

# get tokens and addresses automatically, if data_dir_path is not empty
if data_dir_path and kmd_folder_name:
    if not data_dir_path[-1] == "/":
        data_dir_path += "/"
    if not kmd_folder_name[-1] == "/":
        kmd_folder_name += "/"
    # algod_token = open(data_dir_path + "algod.token", "r").read().strip("\n")
    # algod_address = "http://" + open(data_dir_path + "algod.net",
    #                                  "r").read().strip("\n")
    # algod_address = "http://" + open("/node/data" + "algod.net",
    #                                  "r").read().strip("\n")
    algod_address = "http://r1.algorand.network:8161"
    kmd_token = open(data_dir_path + kmd_folder_name + "kmd.token",
                     "r").read().strip("\n")
    kmd_address = "http://" + open(data_dir_path + kmd_folder_name + "kmd.net",
                                   "r").read().strip("\n")
